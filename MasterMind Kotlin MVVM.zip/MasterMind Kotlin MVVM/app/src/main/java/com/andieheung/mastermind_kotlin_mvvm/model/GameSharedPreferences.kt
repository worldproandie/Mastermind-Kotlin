package com.andieheung.mastermind_kotlin_mvvm.model

import android.content.Context
import android.content.SharedPreferences

abstract class GameSharedPreferences protected constructor(protected val context: Context) {

    protected var prefs: SharedPreferences = this.context.getSharedPreferences(
        "mastermind", Context.MODE_PRIVATE
    )
    private val editor: SharedPreferences.Editor = prefs.edit()

    protected fun writePref(key: String, value : Any){
        when(value) {
            is String -> editor.putString(key, value)
            is Int -> editor.putInt(key, value)
            is Boolean -> editor.putBoolean(key, value)
            is Long -> editor.putLong(key, value)
            is Float -> editor.putFloat(key, value)
            else -> error("Invalid value type!")
        }
    }
}
