package com.andieheung.mastermind_kotlin_mvvm.manager

import android.content.Context
import com.andieheung.mastermind_kotlin_mvvm.model.Hint
import com.andieheung.mastermind_kotlin_mvvm.model.PinColorList

interface GameDataManager {

    var numPin: Int
    var numColor: Int

    var currentGuess: PinColorList?
    var gameAns: PinColorList?

    val numAttempt: Int
    val timeSpentStr: String

    val playerName: String
    val numAttemptSetting: Int

    fun init(context: Context)
    fun onStartGame()
    fun onEndGame()
    fun onResumeGame()
    fun onPauseGame()

    fun gameStarted(): Boolean
    fun gameStartedPaused(): Boolean
    fun gameStartedNotPaused(): Boolean
    fun remainingAttempt(): Int
    fun incrementNumAttempt()
    fun incrementTimeSpent()
    fun completeGuessAttempt(): Boolean
    fun updateCurrentGuess(pos: Int, pinColorOrdinal: Int)
    fun checkIfBingo(): Boolean
    fun reachMaxAttempt(): Boolean
    fun resetGuessAttempt()
    fun generateHint(): Hint
    fun generateAns(): PinColorList

}