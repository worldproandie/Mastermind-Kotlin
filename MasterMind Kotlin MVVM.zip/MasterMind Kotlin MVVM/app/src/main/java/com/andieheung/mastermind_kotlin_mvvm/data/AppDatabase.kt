package com.andieheung.mastermind_kotlin_mvvm.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.andieheung.mastermind_kotlin_mvvm.data.game_attempt.GameAttempt
import com.andieheung.mastermind_kotlin_mvvm.data.game_attempt.GameAttemptsDao

@Database(entities = arrayOf(GameAttempt::class), version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun gameAttemptDao(): GameAttemptsDao
    companion object {

        private var INSTANCE: AppDatabase? = null

        private val lock = Any()

        fun getInstance(context: Context): AppDatabase {
            synchronized(lock) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.applicationContext,
                        AppDatabase::class.java, "GameAttempts.db")
                        .build()
                }
                return INSTANCE!!
            }
        }
    }
}