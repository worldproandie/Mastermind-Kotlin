package com.andieheung.mastermind_kotlin_mvvm.data.game_attempt

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "game_attempts")
data class GameAttempt constructor(
    @ColumnInfo(name = "player_id") var player_id : String = "",
    @ColumnInfo(name = "num_attempted") var num_attempted : Int = 0,
    @ColumnInfo(name = "time_spent") var time_spent : Long = 0,
    @ColumnInfo(name = "status") var status : Int = 0,
    @ColumnInfo(name = "num_pin") var num_pin : Int = 0,
    @ColumnInfo(name = "num_color") var num_color : Int = 0,
    @ColumnInfo(name = "timestamp") var timeStamp : String =  " time('now') ",
    @PrimaryKey @ColumnInfo(name = "id") var id : String = UUID.randomUUID().toString()
)