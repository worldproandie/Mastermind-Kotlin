package com.andieheung.mastermind_kotlin_mvvm.model

import android.content.Context

class GameSetting private constructor(context: Context) : GameSharedPreferences(context) {

    var playerName: String
        get() = prefs.getString("playerName", "MMPlayer")
        set(name) {
            writePref("playerName", name)
        }

    var numPin: Int
        get() = prefs.getInt("numPins", 4)
        set(num) {
            writePref("numPins", num)
        }

    var numColor: Int
        get() = prefs.getInt("num_color", 5)
        set(num) {
            writePref("num_color", num)
        }

    var numAttempt: Int
        get() = prefs.getInt("num_attempt", 12)
        set(num) {
            writePref("num_attempt", num)
        }

    companion object {
        @Volatile private var INSTANCE: GameSetting? = null

        fun getInstance(context: Context): GameSetting =
            INSTANCE ?: synchronized(this) {
            INSTANCE ?: GameSetting(context).also { INSTANCE = it }
        }
    }
}