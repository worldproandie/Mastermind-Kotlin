package com.andieheung.mastermind_kotlin_mvvm.utils

import android.content.Context
import com.andieheung.mastermind_kotlin_mvvm.data.AppDatabase
import com.andieheung.mastermind_kotlin_mvvm.data.game_attempt.GameAttemptsLocalDataSource
import com.andieheung.mastermind_kotlin_mvvm.data.game_attempt.GameAttemptsRepository

object Injection {

    fun provideGameAttemptsRepository(context: Context): GameAttemptsRepository {
        val database = AppDatabase.getInstance(context)
        return GameAttemptsRepository.getInstance(
            GameAttemptsLocalDataSource.getInstance(AppExecutors(), database.gameAttemptDao()))
    }
}
